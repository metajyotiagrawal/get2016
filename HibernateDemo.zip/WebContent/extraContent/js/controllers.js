/* The controller for getting the car list */
listOfCars.controller('carList', function($scope, $http) {

	/* For getting the list of cars available */
	$scope.loadCars = function() {
		
		$http({
			method : 'GET',
			url : 'carlist'}).then(function(response) {
			console.log("come");
			if (response.status === 200) {
				console.log("aao");
				console.log(response.data.data);
				$scope.cars = response.data.data;
			}
		});
	}
});

