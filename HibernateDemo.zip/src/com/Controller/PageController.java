package com.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.Model.CarFacade;
import com.Model.CarVO;

@Controller
public class PageController {
	/**
	 * For mapping the home page
	 * 
	 * @return - The page name to render
	 */

	@RequestMapping("/")
	public String showIndexPage() {
		return "Home";
	}

	@RequestMapping("/displayCarList")
	public String showCarListPage() {
		return "displayCarList";
	}

	@RequestMapping("/Car")
	public String addCar() {
		return "form";
	}

	@RequestMapping("/addCar")
	public String saveCar(HttpServletRequest request) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"/com/Model/beanContext.xml");
		CarVO car = context.getBean("CarVO", CarVO.class);

		CarFacade facade = context.getBean("CarFacade", CarFacade.class);
		String carname = request.getParameter("name");

		String model = request.getParameter("model");
		String make = request.getParameter("make");
		String rate = request.getParameter("price");

		int price = Integer.parseInt(rate);
		car.setModel(model);
		car.setMake(make);
		car.setPrice(price);
		car.setName(carname);

		System.out.println("make: " + car.getMake());
		Boolean flag = facade.insertCar(car);

		if (flag == false)
			return "/";
		else
			return "success";
	}

	@RequestMapping(value = "/carlist", method = RequestMethod.GET)
	public @ResponseBody Response showCarList() {

		// Getting the object of Car Facade Class
		CarFacade facade = CarFacade.getFacade();
		// Getting the list of cars
		List<CarVO> carList = facade.getCarList();
		System.out.println("car" + carList.get(0).getModel());

		return new Response(carList);
	}
}
