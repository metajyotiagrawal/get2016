package com.Model;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

@SuppressWarnings("deprecation")
@Repository
public class CarDao 
{
	private static SessionFactory factory;	//To create a session for the database operation

	public SessionFactory getSessionFactory() {
		return factory;
	}

	public void setSessionFactory(SessionFactory factory) {
		this.factory = factory;
	}





	public Boolean addCar(CarVO car) {

		Transaction tx = null;
		Session session = null;
		boolean result = false;
		try {
			
			SessionFactory factory = new Configuration().configure()
					.buildSessionFactory();
			session = factory.openSession();
			tx = session.beginTransaction();

			session.persist(car);

			tx.commit();
			
			result = true;

		} catch (Exception e) {
			System.out.println("here : "+e.getMessage());
			e.printStackTrace();

		}finally {
			if (!tx.wasCommitted()) {
				tx.rollback();
			}//not much doing but a good practice
			session.flush(); //this is where I think things will start working.
			session.close();
		}
		return result;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<CarVO> viewCarList() {
		
		
		List<CarVO>list=null;
		Transaction tx = null;
		Session session = null;
		CarVO car=null;
		try {
			
			SessionFactory factory = new Configuration().configure()
					.buildSessionFactory();
			session = factory.openSession();
			tx = session.beginTransaction();

			
			Criteria cr=(Criteria) session.createCriteria(CarVO.class);
		
	list = cr.list();
		System.out.println(car.getModel());
 
			tx.commit();
			
			

		} catch (Exception e) {
			System.out.println("here : "+e.getMessage());
			e.printStackTrace();

		}finally {
			if (!tx.wasCommitted()) {
				tx.rollback();
			}//not much doing but a good practice
			session.flush(); //this is where I think things will start working.
			session.close();
		}
		return list;
		
		
	}
}