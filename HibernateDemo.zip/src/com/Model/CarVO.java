package com.Model;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
@Entity
@Component
@Table(name = "Car")

public class CarVO {
	
        @Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "ID")
		private int id;

		@Column(name = "NAME")
		private String name;

		@Column(name = "MODEL")
		private String model;

		@Column(name = "MAKE")
		private String make;

		@Column(name = "PRICE")
		private int price;

		public void setId(int id)
		{
			this.id=id;
		}
		public int getId()
		{
			return id;
		}
		public void setName(String name)
		{
			this.name=name;
		}
		public String getName()
		{
			return name;
		}
		
		public void setModel(String model) {
			this.model=model;
		}
		
		public String getModel()
		{
			return model;
		}
		
		public void setMake(String make)
		{
			this.make=make;
		}
		public String getMake()
		{
			return make;
		}
		public void setPrice(int price)
		{
			this.price=price;
		}
		public int getPrice()
		{
			return price;
		}

}