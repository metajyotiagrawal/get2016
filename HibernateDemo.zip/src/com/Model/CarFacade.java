package com.Model;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class CarFacade {
	private static CarFacade facade = null;	//Facade object for singleton pattern
	
	/**
	 * To get the facade object
	 * @return - The Facade object
	 */
	public static CarFacade getFacade() {
		//Checking if facade object already exists or not
		if(facade == null) {
			
			try
			{
			ApplicationContext context = new ClassPathXmlApplicationContext("/com/Model/beanContext.xml");
			//Getting the facade object
			facade = context.getBean("CarFacade", CarFacade.class);
			}
			catch(Exception e)
			{
				System.out.println("error is"+e);
			}
			
		}
		return facade;
	}
	
	@Transactional
	public Boolean insertCar(CarVO car)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("/com/Model/beanContext.xml");
		CarDao dao = context.getBean("CarDao", CarDao.class);
		
		dao.addCar(car);
		return true;
		
	}
	
	public List<CarVO> getCarList() {
	
		ApplicationContext context = new ClassPathXmlApplicationContext("/com/Model/beanContext.xml");
		CarDao carDAO = context.getBean("CarDao", CarDao.class);
		List<CarVO> car= carDAO.viewCarList();
		
		
		
		
		
		return car;
	}
}
