package webservice1;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public class Temperature {

	@WebMethod
	public double convertFarehnitToCelcius(double farhenitTemp){
		double temperatue = ((farhenitTemp - 32)*5)/9;;
		return temperatue;
		
		
	}
}
