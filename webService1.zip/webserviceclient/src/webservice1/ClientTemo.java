package webservice1;


public class ClientTemo {

public static void main(String[] args) {

	TemperatureServiceLocator hello = new TemperatureServiceLocator();
	hello.setTemperatureEndpointAddress("http://localhost:8080/webservice1/services/Temperature");


	try {
	Temperature h = hello.getTemperature();
	System.out.println(h.convertFarehnitToCelcius(40.5));
	} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}

}
}
