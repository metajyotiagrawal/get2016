$("document").ready(init);
function init(){
	$("#start").on('click',fnfloatRight);
	$("#stop").on('click',fnStopAnimation);
	$("#back").on('click',fnfloatLeft);
	$("#left").on('click',fnMoveLeft);
	$("#right").on('click',fnMoveRight);
	$("#top").on('click',fnMoveUp);
	$("#bottom").on('click',fnMoveDown);
	
}
  function fnfloatRight(){
	$("div#div1").animate({left:"+=800px"},10000,"linear");

  }
  function fnStopAnimation(){
	$("div#div1").stop();
   }
  function fnfloatLeft(){
	$("div#div1").animate({left:"-=800px"},10000,"linear");
   }
  function fnMoveLeft(){
	$("div#div1").animate({left:"+=50px"});

  }
  function fnMoveRight(){
	$("div#div1").animate({left:"-=50px"});

  }
  function fnMoveUp(){
	$("div#div1").animate({top:"-=50px"});

  }
  function fnMoveDown(){
	$("div#div1").animate({top:"+=50px"});

  }