package databases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;





import Models.CarVO;

public class CarDao {
	ConnectionSingleton jdbc;
	Connection con=null;
	public CarDao()
	{
	
	 jdbc= ConnectionSingleton.getInstance();  
	 try
		{
		 con=jdbc.getConnection();
		}
		catch(Exception e)
		{
			System.out.println("error in establishing connection");
		}
	}
	 public static java.sql.Date getCurrentJavaSqlDate() {
		    java.util.Date today = new java.util.Date();
		    return new java.sql.Date(today.getTime());
		  }
	
	public Boolean insertCar(CarVO car)
	{
	
		int f=0;
		
		
		String query="insert into Car(creator,createdTime,updateBy,updatedTime,model,engineCC,fuelCap,milage,price,tax,ac,powersteer,accKit,name) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try
		{
		PreparedStatement ps = con.prepareStatement(query);
		java.sql.Date date = getCurrentJavaSqlDate();
	     
		   System.out.println(date);
		ps.setString(1,car.getMake());
		ps.setDate(2,date);
		ps.setString(3,car.getMake() );
		ps.setDate(4, date);
		ps.setString(5,car.getModel());
		ps.setString(6, car.getEngineCC());
		ps.setFloat(7,car.getFuelCap());
		ps.setFloat(8,car.getMileage());
		ps.setFloat(9,car.getPrice());
		ps.setFloat(10,car.getRoadTax());
		ps.setString(11, car.getAC());
		ps.setString(12,car.getPowerSteeer());
		ps.setString(13,car.getAccKit());
		ps.setString(14,car.getName());
		
 f=ps.executeUpdate();
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		try
		{
			
			con.close();
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		if(f>0)
	    
		return true;
		else
			return false;
	}
	public Boolean updateCar(String updateBased,CarVO car)
	{
	
		int f=0;
		
String query = "UPDATE car set creator=? , createdTime=? ,updateBy=? ,updatedTime=? ,model=? , engineCC=? , fuelcap=? , milage=? , price=? , tax=?"
		+ ", ac=? , powerSteer=? , accKit=? , name=? where model=?";
                

		try
		{
		PreparedStatement ps = con.prepareStatement(query);
		java.sql.Date date = getCurrentJavaSqlDate();
	     
		   System.out.println(date);
		ps.setString(1,car.getMake());
		System.out.println("Make"+car.getMake());
		ps.setDate(2,date);
		System.out.println("date"+date);
		ps.setString(3,car.getMake() );
		System.out.println("make"+car.getMake());
		ps.setDate(4, date);
		System.out.println("date"+date);
	  ps.setString(5,car.getModel());
		System.out.println("model"+car.getModel());
		ps.setString(6, car.getEngineCC());
		System.out.println("engine"+car.getEngineCC());
		ps.setFloat(7,car.getFuelCap());
		System.out.println("fuel"+car.getFuelCap());
		ps.setFloat(8,car.getMileage());
		System.out.println("mileage"+car.getMileage());
		ps.setFloat(9,car.getPrice());
		System.out.println("price"+car.getPrice());
		ps.setFloat(10,car.getRoadTax());
		System.out.println("tax"+car.getRoadTax());
		ps.setString(11, car.getAC());
		System.out.println("ac"+car.getAC());
		ps.setString(12,car.getPowerSteeer());
		System.out.println("power"+car.getPowerSteeer());
		ps.setString(13,car.getAccKit());
		System.out.println("acckit"+car.getAccKit());
		ps.setString(14,car.getName());
		System.out.println("carname"+car.getName());
		ps.setString(15,updateBased);
		System.out.println("model"+updateBased);
        f=ps.executeUpdate();
        System.out.println(f);
		}
		catch(SQLException e)
		{
			System.out.println("riya"+e);
		}
		try
		{
			
			con.close();
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		if(f>0)
	    
		return true;
		else
			return false;
	}
	public ResultSet searchCarBy(String query,String searchBy,String data)
	{
		//int carSize=searchCar(carName);
		//String query="select * from car where name=?";
		//CarVO car[]=new CarVO[carSize];
		ResultSet rs=null;
		int i=0;
		try
		{
		PreparedStatement ps = con.prepareStatement(query);
		if(data=="float")
		{
			float price=Float.parseFloat(searchBy);
		ps.setFloat(1,price);
		}
		else
		{
			ps.setString(1,searchBy);
		}
		 rs=ps.executeQuery();
		
		}
		catch(SQLException e)
		{
			System.out.println("Error"+e);
			
		}
		return rs;
		
	}
	public ResultSet viewCarList(String query)
	{
		ResultSet rs=null;
		int i=0;
		try
		{
		PreparedStatement ps = con.prepareStatement(query);
	
		 rs=ps.executeQuery();
		
		}
		catch(SQLException e)
		{
			System.out.println("Error"+e);
			
		}
		return rs;
	}
	int searchCar(String car)
	{
		String query="select count(*) from car where name=?";
		int count=0;
		try
		{
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1,car);
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			count=rs.getInt(1);
			
		}
		}
		catch(SQLException e)
		{
			System.out.println("Error"+e);
			
		}
		return count;
	}
	
}
