package com.Model;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CarFacade {
	private static CarFacade facade = null;	//Facade object for singleton pattern
 
	
	/**
	 * To get the facade object
	 * @return - The Facade object
	 */
	public static CarFacade getFacade() {
		//Checking if facade object already exists or not
		if(facade == null) {
			
			try
			{
			ApplicationContext context = new ClassPathXmlApplicationContext("/com/Model/beanContext.xml");
			//Getting the facade object
			facade = context.getBean("CarFacade", CarFacade.class);
			}
			catch(Exception e)
			{
				System.out.println("error is"+e);
			}
			
		}
		return facade;
	}
	public List<CarVO> getCarList() {
		List<CarVO> carVOList = new ArrayList<CarVO>();
		ApplicationContext context = new ClassPathXmlApplicationContext("/com/Model/beanContext.xml");
		CarDao carDAO = context.getBean("CarDao", CarDao.class);
		ResultSet result = carDAO.viewCarList();
		
		
		CarVO car;
		
		try {
			//Iterating over the result set
			while(result.next()) {
				car = context.getBean("CarVO", CarVO.class);
				
				car.setModel(result.getString("model"));
				
				carVOList.add(car);
			}
			
			((ClassPathXmlApplicationContext)context).close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return carVOList;
	}
	
}
