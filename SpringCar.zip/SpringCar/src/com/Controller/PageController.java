package com.Controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.Model.CarDao;
import com.Model.CarFacade;
import com.Model.CarVO;

@Controller
public class PageController {
	/**
	 * For mapping the home page
	 * 
	 * @return - The page name to render
	 */

	@RequestMapping("/")
	public String showIndexPage() {
		return "Home";
	}

	@RequestMapping("/displayCarList")
	public String showCarListPage() {
		return "displayCars";
	}

	@RequestMapping(value = "/carlist", method = RequestMethod.GET)
	public @ResponseBody Response showCarList() {

		// Getting the object of Car Facade Class
		CarFacade facade = CarFacade.getFacade();
		// Getting the list of cars
		List<CarVO> carList = facade.getCarList();
		return new Response(carList);
	}

	@RequestMapping("/Car")
	public String addCar() {
		return "form";
	}

	@RequestMapping("/addCar")
	public String saveCar(HttpServletRequest request) {
		System.out.println("dfd");
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"/com/Model/beanContext.xml");
		CarVO car = context.getBean("CarVO", CarVO.class);
		CarDao dao = context.getBean("CarDao", CarDao.class);
		String carname = request.getParameter("carName");
		String carCreater = request.getParameter("carCreater");
		String model = request.getParameter("model");

		String mile = request.getParameter("milage");
		float mileage = Float.parseFloat(mile);
		String engineCC = request.getParameter("engine");
		String fuel = request.getParameter("fuel");
		float fuelCap = Float.parseFloat(fuel);
		String price = request.getParameter("price");
		float carPrice = Float.parseFloat(price);
		String tax = request.getParameter("tax");
		float roadTax = Float.parseFloat(tax);
		String ac = request.getParameter("ac");
		String powerSteer = request.getParameter("powerSteer");
		String accKit = request.getParameter("accKit");
		System.out.println(carname);

		car.setName(carname);
		car.setMake(carCreater);
		car.setModel(model);
		car.setMileage(mileage);
		car.setEngineCC(engineCC);
		car.setFuelCap(fuelCap);
		car.setPrice(carPrice);
		car.setRoadTax(roadTax);
		car.setAC(ac);
		car.setPowerSteeer(powerSteer);
		car.setAccKit(accKit);

		Boolean flag = dao.insertCar(car);
		System.out.println(flag);
		if (flag == false)
			return "/";
		else
			return "success";
	}

	@RequestMapping("cardetails")
	public String showCarDetailsPage(@RequestParam("model") String model,
			ModelMap mode) {
		mode.addAttribute("model", model);
		return "displayCarBy";
	}

	@RequestMapping(value = "/allcardetails", method = RequestMethod.GET)
	public @ResponseBody Response showCarDetails(
			@RequestParam("model") String model) {
		// Getting the object of Car Facade Class
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"/com/Model/beanContext.xml");
		CarDao dao = context.getBean("CarDao", CarDao.class);

		// Getting the car details
		System.out.println("model is"+model);
		ArrayList<CarVO> car = dao.searchCarByModel(model);
		System.out.println("car vbghy"+car.size());
		return new Response(car);
	}

	@RequestMapping("caredit")
	public String showCarEditPage(@RequestParam("model") String model,
			ModelMap mode) {
		mode.addAttribute("model", model);
		return "CarUpdate";
	}

	@RequestMapping(value = "/carUpdate", method = RequestMethod.POST)
	public String carUpdate(@RequestBody CarVO model) {
		// Getting the object of Car Facade Class
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"/com/Model/beanContext.xml");
		CarDao dao = context.getBean("CarDao", CarDao.class);
		CarVO car = context.getBean("CarVO", CarVO.class);
		boolean flag = dao.updateCar(model.getModel(), model);
		if (flag == false)
			return "/";
		else
			return "success";
	}
}
