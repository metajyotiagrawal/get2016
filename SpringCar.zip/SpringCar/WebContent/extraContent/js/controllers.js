/* The controller for getting the car list */
listOfCars.controller('carList', function($scope, $http) {

    /* For getting the list of cars available */
    $scope.loadCars = function(){
    	console.log("dfdf");
        $http({method: 'GET', url: 'carlist'}).then(function(response) {
        	console.log("come");
            if (response.status === 200) {
            	console.log("aao");
            	console.log(response.data.data);
                $scope.cars = response.data.data;
            }
        });
    }
});

carDetails.controller('details',function($scope,$http) {
	
/* For loading the car details */
    $scope.getCarDetail = function(model){
    	console.log('djkashdhsj');
        $http({method: 'GET', url: 'allcardetails?model='+model}).then(function(response) {
            if (response.status === 200) {
                $scope.car = response.data.data;
                console.log("dfjgj"+$scope.car);
            }
        });
    }
});
updateCar.controller('editCar', function($scope, $http) {



	   /* For getting the car detail  available */
	   $scope.getCar = function(m){
	   console.log("model "+m);
	       $http({method: 'GET', url: 'allcardetails?model='+m}).then(function(response) {
	           if (response.status === 200) {
	           
	           
	               $scope.carInfo= response.data.data;
	               console.log($scope.carInfo);
	               
	           }
	       });
	   }
	   
	   $scope.updateCar = function(){
	   
		   console.log($scope.carInfo[0]);
	    $http.post("carUpdate", $scope.carInfo[0]).success(function (data) {
	    console.log(data);
	       });
	   }
	});