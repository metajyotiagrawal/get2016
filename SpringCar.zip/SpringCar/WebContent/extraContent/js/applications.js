/* Getting the list of car page application */
var listOfCars = angular.module('listOfCars',[]);

var carDetails = angular.module('carDetails',[]);

var updateCar = angular.module('updateCar', []);
