$("document").ready(init);
function init(){
$( "#age" ).keyup(function() {
  var value = $("#age").val();
 
  $( "#emptyDiv" ).text( value );
});

$( "#nm" ).keyup(function() {
  var value = $("#nm").val();
 
  $( "#emptyDiv" ).text( value );
});

$( "#add" ).keyup(function() {
  var value = $("#add").val();
 
  $( "#emptyDiv" ).text( value );
});
}