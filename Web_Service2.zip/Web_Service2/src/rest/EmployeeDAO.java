package rest;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.sql.*;

public class EmployeeDAO {
	
	public ArrayList<EmployeeVO> getAllEmployees() throws SQLException, ClassNotFoundException{
		List<EmployeeVO> empList=new ArrayList<EmployeeVO>();
		try{
		Connection con=DBConnection.getInstance().getConnection();
	    Statement st = (Statement) con.createStatement();
		
		String query = "SELECT * FROM empdetail";
		ResultSet rslt=st.executeQuery(query);
		 EmployeeVO emp=new EmployeeVO();
		 while(rslt.next()){
	        	emp.setId(rslt.getString(1));
	        	emp.setName(rslt.getString(2));
	        	emp.setDepartment(rslt.getString(3));
	        	empList.add(emp);
	        }
		 
		 return  (ArrayList<EmployeeVO>) empList;
		}
		catch(SQLException e){
			throw e;
		}
	}
	
	
	public ArrayList<EmployeeVO> getEmployeeById(String empId) throws SQLException, ClassNotFoundException{
		List<EmployeeVO> empList=new ArrayList<EmployeeVO>();
		try{
		Connection con=DBConnection.getInstance().getConnection();
	    Statement st = (Statement) con.createStatement();
		
		String query = "SELECT * FROM empdetail WHERE ID='"+empId+"'";
		ResultSet rslt=st.executeQuery(query);
		 EmployeeVO emp=new EmployeeVO();
		 while(rslt.next()){
	        	emp.setId(rslt.getString(1));
	        	emp.setName(rslt.getString(2));
	        	emp.setDepartment(rslt.getString(3));
	        	empList.add(emp);
	        }
		 
		 return  (ArrayList<EmployeeVO>) empList;
		}
		catch(SQLException e){
			throw e;
		}
	}
	
	public ArrayList<EmployeeVO> createEmployee(String empId,String empName,String dpt) throws SQLException, ClassNotFoundException{
		List<EmployeeVO> empList=new ArrayList<EmployeeVO>();
		try{
		Connection con=DBConnection.getInstance().getConnection();
	    Statement st = (Statement) con.createStatement();
		
		String query = "INSERT INTO empdetail VALUES("+empId+","+empName+","+dpt+")";
		ResultSet rslt=st.executeQuery(query);
		 EmployeeVO emp=new EmployeeVO();
		 while(rslt.next()){
	        	emp.setId(rslt.getString(1));
	        	emp.setName(rslt.getString(2));
	        	emp.setDepartment(rslt.getString(3));
	        	empList.add(emp);
	        }
		 
		 return  (ArrayList<EmployeeVO>) empList;
		}
		catch(SQLException e){
			throw e;
		}
	}
	
	public ArrayList<EmployeeVO> getEmployeesByName(String empName) throws SQLException, ClassNotFoundException{
		List<EmployeeVO> empList=new ArrayList<EmployeeVO>();
		try{
		Connection con=DBConnection.getInstance().getConnection();
	    Statement st = (Statement) con.createStatement();
		
		String query = "SELECT * FROM empdetail WHERE Name='"+empName+"'";
		ResultSet rslt=st.executeQuery(query);
		 EmployeeVO emp=new EmployeeVO();
		 while(rslt.next()){
	        	emp.setId(rslt.getString(1));
	        	emp.setName(rslt.getString(2));
	        	emp.setDepartment(rslt.getString(3));
	        	empList.add(emp);
	        }
		 
		 return  (ArrayList<EmployeeVO>) empList;
		}
		catch(SQLException e){
			throw e;
		}
	}

	public ArrayList<EmployeeVO> deleteEmployeeById(String empId) throws SQLException, ClassNotFoundException{
		List<EmployeeVO> empList=new ArrayList<EmployeeVO>();
		try{
		Connection con=DBConnection.getInstance().getConnection();
	    Statement st = (Statement) con.createStatement();
		
		String query = "DELETE FROM empdetail WHERE ID='"+empId+"'";
		ResultSet rslt=st.executeQuery(query);
		 EmployeeVO emp=new EmployeeVO();
		 while(rslt.next()){
	        	emp.setId(rslt.getString(1));
	        	emp.setName(rslt.getString(2));
	        	emp.setDepartment(rslt.getString(3));
	        	empList.add(emp);
	        }
		 
		 return  (ArrayList<EmployeeVO>) empList;
		}
		catch(SQLException e){
			throw e;
		}
	}
	
	
}
