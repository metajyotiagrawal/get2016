package rest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnection {
	private static DBConnection connection=null;
	private DBConnection(){}
	private DBConnection con;
	
	
	public static DBConnection getInstance(){
		if(connection==null){
			connection=new DBConnection();
		}
		
		return connection;
	}

	/*
	 * to establish connection steps include load or register driver establish
	 * connection using connection class create statement using statement class
	 */
	  protected Connection getConnection()throws ClassNotFoundException, SQLException  
      {  
           
          Connection con=null;  
          Class.forName("com.mysql.jdbc.Driver");  
          con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "jyoti");  
         
          return con;  
           
      } 
}
