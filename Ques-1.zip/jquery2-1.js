$("document").ready(init);
function init(){
	$("#but").on('click',fnChangeText);
}
function fnChangeText(){
	$('.hello').text("Hello World!");
	
	
	
}